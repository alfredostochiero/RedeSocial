<?php
namespace src\models;
use \core\Model;

class User extends Model {

}