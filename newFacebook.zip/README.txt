Rede Social criada em PHP7.4

